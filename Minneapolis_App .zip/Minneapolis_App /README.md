# Minneapolis Cab App

A demo MVP cab booking app with full customer/driver flows for Minneapolis, built with React, Vite, and Tailwind CSS.

## Usage

- `npm install`
- `npm run dev` (local)
- Push to GitHub, then deploy on Vercel!
